def main():
    indoor = input("Hello, what do you have to say? ")
    print(indoor.lower())
main()
