def main():
    text = input("Type your text! ")
    emojize = convert(text)
    print(emojize)


def convert(text):
    text1 = text.replace(":)", "🙂")
    text2 = text1.replace(":(", "🙁")
    return text2
main()
