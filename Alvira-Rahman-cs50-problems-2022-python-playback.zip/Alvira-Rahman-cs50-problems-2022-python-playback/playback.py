playback = input("What is your Playback speech? ")

new_playback = playback.replace(" ", "...")

print(new_playback)
