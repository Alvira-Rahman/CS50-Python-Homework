def main():
    n = 300000000
    c = int(pow(n, 2))
    m = int(input("Please insert the value of Mass "))
    einstein = int(m * c)
    print(einstein)

main()
